#include "../../../../runtime/headers.h"

const rapidcsv::Document CHT_CSV("../datasets/lsqb/Comment_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document PHT_CSV("../datasets/lsqb/Post_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));

auto cht = std::tuple(/* CommentId */ CHT_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(CHT_CSV.GetRowCount()));

auto comment = std::tuple(/* CommentId */ COMMENT_CSV.GetColumn<long>(0),
        /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
        /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto pht = std::tuple(/* PostId */ PHT_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(PHT_CSV.GetRowCount()));

int main() {
    vector<int> comment_offsets(std::get<2>(comment));
    iota(comment_offsets.begin(), comment_offsets.end(), 0);
    sort(comment_offsets.begin(), comment_offsets.end(), [&](const int i, const int j) { return std::get<0>(comment)[i] < std::get<0>(comment)[j]; });
    vector<int> pht_offsets(std::get<1>(pht));
    iota(pht_offsets.begin(), pht_offsets.end(), 0);
    sort(pht_offsets.begin(), pht_offsets.end(), [&](const int i, const int j) { return std::get<0>(pht)[i] < std::get<0>(pht)[j]; });
    
    HighPrecisionTimer timer;
    for (int iter = 0; iter <= 5; iter++) {
        timer.Reset();
        SortedDict<long, Range> comment_trie0(/* size */ std::get<2>(comment));
        for (int i = 0; i < /* size */ std::get<2>(comment); i++) {
            comment_trie0[/* CommentId */ std::get<0>(comment)[comment_offsets[i]]][i] += 1;
        }
        SortedDict<long, int> pht_trie0(/* size */ std::get<1>(pht));
        for (int i = 0; i < /* size */ std::get<1>(pht); i++) {
            pht_trie0[/* PostId */ std::get<0>(pht)[pht_offsets[i]]] += 1;
        }
        auto result = int(0);
        for (int cht_off = 0; cht_off < /* size */ std::get<1>(cht); cht_off++) {
            const auto x0 = /* CommentId */ std::get<0>(cht)[cht_off];
            const auto comment_it = comment_trie0.find(x0);
            if (comment_it != comment_trie0.end()) {
                const auto &comment_trie1 = comment_it->second;
                for (auto comment_i = comment_trie1.left(); comment_i < comment_trie1.right(); comment_i++) {
                    const auto comment_off = comment_offsets[comment_i];
                    const auto x1 = /* replyOf_PostId */ std::get<1>(comment)[comment_off];
                    const auto pht_it = pht_trie0.find(x1);
                    if (pht_it != pht_trie0.end()) {
                        const auto &pht_trie1 = pht_it->second;
                        result += pht_trie1;
                    }
                }
            }
        }
        timer.StoreElapsedTime(0);
        std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
    }
    cout << timer.GetMean(0) << " ms" << endl;
}