#include "../../../../runtime/headers.h"

const rapidcsv::Document CHT_CSV("../datasets/lsqb/Comment_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document CITY_CSV("../datasets/lsqb/City.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));
const rapidcsv::Document COUNTRY_CSV("../datasets/lsqb/Country.csv", NO_HEADERS, SEPARATOR, IntNanConverter(3));
const rapidcsv::Document FHP_CSV("../datasets/lsqb/Forum_hasMember_Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(4));
const rapidcsv::Document FORUM_CSV("../datasets/lsqb/Forum.csv", NO_HEADERS, SEPARATOR, IntNanConverter(5));
const rapidcsv::Document PERSON_CSV("../datasets/lsqb/Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(6));
const rapidcsv::Document POST_CSV("../datasets/lsqb/Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(7));
const rapidcsv::Document TAG_CSV("../datasets/lsqb/Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(8));
const rapidcsv::Document TAGCLASS_CSV("../datasets/lsqb/TagClass.csv", NO_HEADERS, SEPARATOR, IntNanConverter(9));

auto cht = std::tuple(/* CommentId */ CHT_CSV.GetColumn<long>(0),
        /* TagId */ CHT_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(CHT_CSV.GetRowCount()));

auto city = std::tuple(/* CityId */ CITY_CSV.GetColumn<long>(0),
        /* isPartOf_CountryId */ CITY_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(CITY_CSV.GetRowCount()));

auto comment = std::tuple(/* CommentId */ COMMENT_CSV.GetColumn<long>(0),
        /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
        /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto country = std::tuple(/* CountryId */ COUNTRY_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(COUNTRY_CSV.GetRowCount()));

auto fhp = std::tuple(/* ForumId */ FHP_CSV.GetColumn<long>(0),
        /* PersonId */ FHP_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(FHP_CSV.GetRowCount()));

auto forum = std::tuple(/* ForumId */ FORUM_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(FORUM_CSV.GetRowCount()));

auto person = std::tuple(/* PersonId */ PERSON_CSV.GetColumn<long>(0),
        /* isLocatedIn_CityId */ PERSON_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(PERSON_CSV.GetRowCount()));

auto post = std::tuple(/* PostId */ POST_CSV.GetColumn<long>(0),
        /* Forum_containerOfId */ POST_CSV.GetColumn<long>(2),
        /* size */ static_cast<int>(POST_CSV.GetRowCount()));

auto tag = std::tuple(/* TagId */ TAG_CSV.GetColumn<long>(0),
        /* hasType_TagClassId */ TAG_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(TAG_CSV.GetRowCount()));

auto tagclass = std::tuple(/* TagClassId */ TAGCLASS_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(TAGCLASS_CSV.GetRowCount()));

int main() {
    vector<int> tagclass_offsets(std::get<1>(tagclass));
    iota(tagclass_offsets.begin(), tagclass_offsets.end(), 0);
    sort(tagclass_offsets.begin(), tagclass_offsets.end(), [&](const int i, const int j) { return std::get<0>(tagclass)[i] < std::get<0>(tagclass)[j]; });
    vector<int> comment_offsets(std::get<2>(comment));
    iota(comment_offsets.begin(), comment_offsets.end(), 0);
    sort(comment_offsets.begin(), comment_offsets.end(), [&](const int i, const int j) { return std::get<0>(comment)[i] < std::get<0>(comment)[j]; });
    vector<int> post_offsets(std::get<2>(post));
    iota(post_offsets.begin(), post_offsets.end(), 0);
    sort(post_offsets.begin(), post_offsets.end(), [&](const int i, const int j) { return std::get<0>(post)[i] < std::get<0>(post)[j]; });
    vector<int> forum_offsets(std::get<1>(forum));
    iota(forum_offsets.begin(), forum_offsets.end(), 0);
    sort(forum_offsets.begin(), forum_offsets.end(), [&](const int i, const int j) { return std::get<0>(forum)[i] < std::get<0>(forum)[j]; });
    vector<int> person_offsets(std::get<2>(person));
    iota(person_offsets.begin(), person_offsets.end(), 0);
    sort(person_offsets.begin(), person_offsets.end(), [&](const int i, const int j) { return std::get<0>(person)[i] < std::get<0>(person)[j]; });
    vector<int> city_offsets(std::get<2>(city));
    iota(city_offsets.begin(), city_offsets.end(), 0);
    sort(city_offsets.begin(), city_offsets.end(), [&](const int i, const int j) { return std::get<0>(city)[i] < std::get<0>(city)[j]; });
    vector<int> country_offsets(std::get<1>(country));
    iota(country_offsets.begin(), country_offsets.end(), 0);
    sort(country_offsets.begin(), country_offsets.end(), [&](const int i, const int j) { return std::get<0>(country)[i] < std::get<0>(country)[j]; });

    HighPrecisionTimer timer;
    for (int iter = 0; iter <= 5; ++iter) {
        timer.Reset();
        SortedDict<long, int> tagclass_trie0(/* size */ std::get<1>(tagclass));
        for (int i = 0; i < /* size */ std::get<1>(tagclass); i++) {
            tagclass_trie0[/* TagClassId */ std::get<0>(tagclass)[tagclass_offsets[i]]] += 1;
        }
        auto interm0_trie0 = phmap::flat_hash_map<long, int>({});
        for (int tag_off = 0; tag_off < /* size */ std::get<2>(tag); tag_off++) {
            const auto x0 = /* hasType_TagClassId */ std::get<1>(tag)[tag_off];
            const auto tagclass_it = tagclass_trie0.find(x0);
            if (tagclass_it != tagclass_trie0.end()) {
                const auto &tagclass_trie1 = tagclass_it->second;
                interm0_trie0[/* TagId */ std::get<0>(tag)[tag_off]] += tagclass_trie1;
            }
        }
        SortedDict<long, Range> comment_trie0(/* size */ std::get<2>(comment));
        for (int i = 0; i < /* size */ std::get<2>(comment); i++) {
            comment_trie0[/* CommentId */ std::get<0>(comment)[comment_offsets[i]]][i] += 1;
        }
        SortedDict<long, Range> post_trie0(/* size */ std::get<2>(post));
        for (int i = 0; i < /* size */ std::get<2>(post); i++) {
            post_trie0[/* PostId */ std::get<0>(post)[post_offsets[i]]][i] += 1;
        }
        SortedDict<long, int> forum_trie0(/* size */ std::get<1>(forum));
        for (int i = 0; i < /* size */ std::get<1>(forum); i++) {
            forum_trie0[/* ForumId */ std::get<0>(forum)[forum_offsets[i]]] += 1;
        }
        auto interm1_trie0 = phmap::flat_hash_map<long, int>({});
        for (int cht_off = 0; cht_off < /* size */ std::get<2>(cht); cht_off++) {
            const auto x0 = /* TagId */ std::get<1>(cht)[cht_off];
            const auto interm0_it = interm0_trie0.find(x0);
            if (interm0_it != interm0_trie0.end()) {
                const auto &interm0_trie1 = interm0_it->second;
                const auto x1 = /* CommentId */ std::get<0>(cht)[cht_off];
                const auto comment_it = comment_trie0.find(x1);
                if (comment_it != comment_trie0.end()) {
                    const auto &comment_trie1 = comment_it->second;
                    for (auto comment_i = comment_trie1.left(); comment_i < comment_trie1.right(); comment_i++) {
                        const auto comment_off = comment_offsets[comment_i];
                        const auto x2 = /* replyOf_PostId */ std::get<1>(comment)[comment_off];
                        const auto post_it = post_trie0.find(x2);
                        if (post_it != post_trie0.end()) {
                            const auto &post_trie1 = post_it->second;
                            for (auto post_i = post_trie1.left(); post_i < post_trie1.right(); post_i++) {
                                const auto post_off = post_offsets[post_i];
                                const auto x3 = /* Forum_containerOfId */ std::get<1>(post)[post_off];
                                const auto forum_it = forum_trie0.find(x3);
                                if (forum_it != forum_trie0.end()) {
                                    const auto forum_trie1 = forum_it->second;
                                    interm1_trie0[x3] += (forum_trie1 * interm0_trie1);
                                }
                            }
                        }
                    }
                }
            }
        }
        SortedDict<long, Range> person_trie0(/* size */ std::get<2>(person));
        for (int i = 0; i < /* size */ std::get<2>(person); i++) {
            person_trie0[/* PersonId */ std::get<0>(person)[person_offsets[i]]][i] += 1;
        }
        SortedDict<long, Range> city_trie0(/* size */ std::get<2>(city));
        for (int i = 0; i < /* size */ std::get<2>(city); i++) {
            city_trie0[/* CityId */ std::get<0>(city)[city_offsets[i]]][i] += 1;
        }
        SortedDict<long, int> country_trie0(/* size */ std::get<1>(country));
        for (int i = 0; i < /* size */ std::get<1>(country); i++) {
            country_trie0[/* CountryId */ std::get<0>(country)[country_offsets[i]]] += 1;
        }
        auto result = int(0);
        for (int fhp_off = 0; fhp_off < /* size */ std::get<2>(fhp); fhp_off++) {
            const auto x0 = /* ForumId */ std::get<0>(fhp)[fhp_off];
            const auto interm1_it = interm1_trie0.find(x0);
            if (interm1_it != interm1_trie0.end()) {
                const auto &interm1_trie1 = interm1_it->second;
                const auto x1 = /* PersonId */ std::get<1>(fhp)[fhp_off];
                const auto person_it = person_trie0.find(x1);
                if (person_it != person_trie0.end()) {
                    const auto &person_trie1 = person_it->second;
                    for (auto person_i = person_trie1.left(); person_i < person_trie1.right(); person_i++) {
                        const auto person_off = person_offsets[person_i];
                        const auto x2 = /* isLocatedIn_CityId */ std::get<1>(person)[person_off];
                        const auto city_it = city_trie0.find(x2);
                        if (city_it != city_trie0.end()) {
                            const auto &city_trie1 = city_it->second;
                            for (auto city_i = city_trie1.left(); city_i < city_trie1.right(); city_i++) {
                                const auto city_off = city_offsets[city_i];
                                const auto x3 = /* isPartOf_CountryId */ std::get<1>(city)[city_off];
                                const auto country_it = country_trie0.find(x3);
                                if (country_it != country_trie0.end()) {
                                    const auto &country_trie1 = country_it->second;
                                    result += (interm1_trie1 * country_trie1);
                                }
                            }
                        }
                    }
                }
            }
        }
        timer.StoreElapsedTime(0);
        std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
    }
    cout << timer.GetMean(0) << " ms" << endl;
}