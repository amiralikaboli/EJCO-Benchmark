#include "../../../../runtime/headers.h"

const rapidcsv::Document CHT_CSV("../datasets/lsqb/Comment_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document CITY_CSV("../datasets/lsqb/City.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));
const rapidcsv::Document COUNTRY_CSV("../datasets/lsqb/Country.csv", NO_HEADERS, SEPARATOR, IntNanConverter(3));
const rapidcsv::Document FHP_CSV("../datasets/lsqb/Forum_hasMember_Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(4));
const rapidcsv::Document FORUM_CSV("../datasets/lsqb/Forum.csv", NO_HEADERS, SEPARATOR, IntNanConverter(5));
const rapidcsv::Document PERSON_CSV("../datasets/lsqb/Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(6));
const rapidcsv::Document POST_CSV("../datasets/lsqb/Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(7));
const rapidcsv::Document TAG_CSV("../datasets/lsqb/Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(8));
const rapidcsv::Document TAGCLASS_CSV("../datasets/lsqb/TagClass.csv", NO_HEADERS, SEPARATOR, IntNanConverter(9));

auto cht = std::tuple(/* CommentId */ CHT_CSV.GetColumn<long>(0),
        /* TagId */ CHT_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(CHT_CSV.GetRowCount()));

auto city = std::tuple(/* CityId */ CITY_CSV.GetColumn<long>(0),
        /* isPartOf_CountryId */ CITY_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(CITY_CSV.GetRowCount()));

auto comment = std::tuple(/* CommentId */ COMMENT_CSV.GetColumn<long>(0),
        /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
        /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto country = std::tuple(/* CountryId */ COUNTRY_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(COUNTRY_CSV.GetRowCount()));

auto fhp = std::tuple(/* ForumId */ FHP_CSV.GetColumn<long>(0),
        /* PersonId */ FHP_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(FHP_CSV.GetRowCount()));

auto forum = std::tuple(/* ForumId */ FORUM_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(FORUM_CSV.GetRowCount()));

auto person = std::tuple(/* PersonId */ PERSON_CSV.GetColumn<long>(0),
        /* isLocatedIn_CityId */ PERSON_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(PERSON_CSV.GetRowCount()));

auto post = std::tuple(/* PostId */ POST_CSV.GetColumn<long>(0),
        /* Forum_containerOfId */ POST_CSV.GetColumn<long>(2),
        /* size */ static_cast<int>(POST_CSV.GetRowCount()));

auto tag = std::tuple(/* TagId */ TAG_CSV.GetColumn<long>(0),
        /* hasType_TagClassId */ TAG_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(TAG_CSV.GetRowCount()));

auto tagclass = std::tuple(/* TagClassId */ TAGCLASS_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(TAGCLASS_CSV.GetRowCount()));

int main() {
    vector<int> tagclass_offsets(std::get<1>(tagclass));
    iota(tagclass_offsets.begin(), tagclass_offsets.end(), 0);
    sort(tagclass_offsets.begin(), tagclass_offsets.end(),
         [&](const int i, const int j) { return std::get<0>(tagclass)[i] < std::get<0>(tagclass)[j]; });
    vector<int> comment_offsets(std::get<2>(comment));
    iota(comment_offsets.begin(), comment_offsets.end(), 0);
    sort(comment_offsets.begin(), comment_offsets.end(), [&](const int i, const int j) {
        if (std::get<0>(comment)[i] != std::get<0>(comment)[j])
            return std::get<0>(comment)[i] < std::get<0>(comment)[j];
        return std::get<1>(comment)[i] < std::get<1>(comment)[j];
    });
    vector<int> post_offsets(std::get<2>(post));
    iota(post_offsets.begin(), post_offsets.end(), 0);
    sort(post_offsets.begin(), post_offsets.end(),
         [&](const int i, const int j) { return std::get<0>(post)[i] < std::get<0>(post)[j]; });
    vector<int> forum_offsets(std::get<1>(forum));
    iota(forum_offsets.begin(), forum_offsets.end(), 0);
    sort(forum_offsets.begin(), forum_offsets.end(),
         [&](const int i, const int j) { return std::get<0>(forum)[i] < std::get<0>(forum)[j]; });
    vector<int> person_offsets(std::get<2>(person));
    iota(person_offsets.begin(), person_offsets.end(), 0);
    sort(person_offsets.begin(), person_offsets.end(), [&](const int i, const int j) {
        if (std::get<0>(person)[i] != std::get<0>(person)[j])
            return std::get<0>(person)[i] < std::get<0>(person)[j];
        return std::get<1>(person)[i] < std::get<1>(person)[j];
    });
    vector<int> city_offsets(std::get<2>(city));
    iota(city_offsets.begin(), city_offsets.end(), 0);
    sort(city_offsets.begin(), city_offsets.end(), [&](const int i, const int j) {
        if (std::get<0>(city)[i] != std::get<0>(city)[j])
            return std::get<0>(city)[i] < std::get<0>(city)[j];
        return std::get<1>(city)[i] < std::get<1>(city)[j];
    });
    vector<int> country_offsets(std::get<1>(country));
    iota(country_offsets.begin(), country_offsets.end(), 0);
    sort(country_offsets.begin(), country_offsets.end(),
         [&](const int i, const int j) { return std::get<0>(country)[i] < std::get<0>(country)[j]; });
    vector<int> tag_offsets(std::get<2>(tag));
    iota(tag_offsets.begin(), tag_offsets.end(), 0);
    sort(tag_offsets.begin(), tag_offsets.end(),
         [&](const int i, const int j) { return std::get<1>(tag)[i] < std::get<1>(tag)[j]; });
    vector<int> cht_offsets(std::get<2>(cht));
    iota(cht_offsets.begin(), cht_offsets.end(), 0);
    sort(cht_offsets.begin(), cht_offsets.end(), [&](const int i, const int j) {
        if (std::get<1>(cht)[i] != std::get<1>(cht)[j])
            return std::get<1>(cht)[i] < std::get<1>(cht)[j];
        return std::get<0>(cht)[i] < std::get<0>(cht)[j];
    });
    vector<int> fhp_offsets(std::get<2>(fhp));
    iota(fhp_offsets.begin(), fhp_offsets.end(), 0);
    sort(fhp_offsets.begin(), fhp_offsets.end(), [&](const int i, const int j) {
        if (std::get<0>(fhp)[i] != std::get<0>(fhp)[j])
            return std::get<0>(fhp)[i] < std::get<0>(fhp)[j];
        return std::get<1>(fhp)[i] < std::get<1>(fhp)[j];
    });

    HighPrecisionTimer timer;
    for (int iter = 0; iter <= 5; ++iter) {
        timer.Reset();
        SortedDict<long, Range> tag_trie0(/* size */ std::get<2>(tag));
        for (int i = 0; i < /* size */ std::get<2>(tag); i++) {
            tag_trie0[/* hasType_TagClassId */ std::get<1>(tag)[tag_offsets[i]]][i] += 1;
        }
        SortedDict<long, int> tagclass_trie0(/* size */ std::get<1>(tagclass));
        for (int i = 0; i < /* size */ std::get<1>(tagclass); i++) {
            tagclass_trie0[/* TagClassId */ std::get<0>(tagclass)[tagclass_offsets[i]]] += 1;
        }
        auto interm0_trie0 = phmap::flat_hash_map<long, int>({});
        for (const auto &[x0, tag_trie1]: tag_trie0) {
            const auto tagclass_it = tagclass_trie0.find(x0);
            if (tagclass_it != tagclass_trie0.end()) {
                const auto &tagclass_trie1 = tagclass_it->second;
                for (auto tag_i = tag_trie1.left(); tag_i < tag_trie1.right(); tag_i++) {
                    const auto tag_off = tag_offsets[tag_i];
                    interm0_trie0[/* TagId */ std::get<0>(tag)[tag_off]] += tagclass_trie1;
                }
            }
        }
        SortedDict<long, SortedDict<long, int>> cht_trie0(/* size */ std::get<2>(cht));
        for (int i = 0; i < /* size */ std::get<2>(cht); i++) {
            cht_trie0[/* TagId */ std::get<1>(cht)[i]][/* CommentId */ std::get<0>(cht)[i]] += 1;
        }
        SortedDict<long, SortedDict<long, int>> comment_trie0(/* size */ std::get<2>(comment));
        for (int i = 0; i < /* size */ std::get<2>(comment); i++) {
            comment_trie0[/* CommentId */ std::get<0>(comment)[comment_offsets[i]]][/* replyOf_PostId */ std::get<1>(
                    comment)[comment_offsets[i]]] += 1;
        }
        SortedDict<long, SortedDict<long, int>> post_trie0(/* size */ std::get<2>(post));
        for (int i = 0; i < /* size */ std::get<2>(post); i++) {
            post_trie0[/* PostId */ std::get<0>(post)[post_offsets[i]]][/* Forum_containerOfId */ std::get<1>(
                    post)[post_offsets[i]]] += 1;
        }
        SortedDict<long, int> forum_trie0(/* size */ std::get<1>(forum));
        for (int i = 0; i < /* size */ std::get<1>(forum); i++) {
            forum_trie0[/* ForumId */ std::get<0>(forum)[forum_offsets[i]]] += 1;
        }
        auto interm1_trie0 = phmap::flat_hash_map<long, int>({});
        for (const auto &[x0, cht_trie1]: cht_trie0) {
            const auto interm0_it = interm0_trie0.find(x0);
            if (interm0_it != interm0_trie0.end()) {
                const auto &interm0_trie1 = interm0_it->second;
                for (const auto &[x1, cht_trie2]: cht_trie1) {
                    const auto comment_it = comment_trie0.find(x1);
                    if (comment_it != comment_trie0.end()) {
                        const auto &comment_trie1 = comment_it->second;
                        for (const auto &[x2, comment_trie2]: comment_trie1) {
                            const auto post_it = post_trie0.find(x2);
                            if (post_it != post_trie0.end()) {
                                const auto &post_trie1 = post_it->second;
                                for (const auto &[x3, post_trie2]: post_trie1) {
                                    const auto forum_it = forum_trie0.find(x3);
                                    if (forum_it != forum_trie0.end()) {
                                        const auto forum_trie1 = forum_it->second;
                                        interm1_trie0[x3] += (
                                                (((cht_trie2 * comment_trie2) * post_trie2) * forum_trie1) *
                                                interm0_trie1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        SortedDict<long, SortedDict<long, int>> fhp_trie0(/* size */ std::get<2>(fhp));
        for (int i = 0; i < /* size */ std::get<2>(fhp); i++) {
            fhp_trie0[/* ForumId */ std::get<0>(fhp)[i]][/* PersonId */ std::get<1>(fhp)[i]] += 1;
        }
        SortedDict<long, SortedDict<long, int>> person_trie0(/* size */ std::get<2>(person));
        for (int i = 0; i < /* size */ std::get<2>(person); i++) {
            person_trie0[/* PersonId */ std::get<0>(person)[person_offsets[i]]][/* isLocatedIn_CityId */ std::get<1>(
                    person)[person_offsets[i]]] += 1;
        }
        SortedDict<long, SortedDict<long, int>> city_trie0(/* size */ std::get<2>(city));
        for (int i = 0; i < /* size */ std::get<2>(city); i++) {
            city_trie0[/* CityId */ std::get<0>(city)[city_offsets[i]]][/* isPartOf_CountryId */ std::get<1>(
                    city)[city_offsets[i]]] += 1;
        }
        SortedDict<long, int> country_trie0(/* size */ std::get<1>(country));
        for (int i = 0; i < /* size */ std::get<1>(country); i++) {
            country_trie0[/* CountryId */ std::get<0>(country)[country_offsets[i]]] += 1;
        }
        auto result = int(0);
        for (const auto &[x0, fhp_trie1]: fhp_trie0) {
            const auto interm1_it = interm1_trie0.find(x0);
            if (interm1_it != interm1_trie0.end()) {
                const auto &interm1_trie1 = interm1_it->second;
                for (const auto &[x1, fhp_trie2]: fhp_trie1) {
                    const auto person_it = person_trie0.find(x1);
                    if (person_it != person_trie0.end()) {
                        const auto &person_trie1 = person_it->second;
                        for (const auto &[x2, person_trie2]: person_trie1) {
                            const auto city_it = city_trie0.find(x2);
                            if (city_it != city_trie0.end()) {
                                const auto &city_trie1 = city_it->second;
                                for (const auto &[x3, city_trie2]: city_trie1) {
                                    const auto country_it = country_trie0.find(x3);
                                    if (country_it != country_trie0.end()) {
                                        const auto &country_trie1 = country_it->second;
                                        result += ((((fhp_trie2 * interm1_trie1) * person_trie2) * city_trie2) *
                                                   country_trie1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        timer.StoreElapsedTime(0);
        std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
    }
    cout << timer.GetMean(0) << " ms" << endl;
}