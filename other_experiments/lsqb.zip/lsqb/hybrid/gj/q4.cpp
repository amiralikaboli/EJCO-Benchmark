#include "../../../../runtime/headers.h"

const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document PHT_CSV("../datasets/lsqb/Post_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document PLP_CSV("../datasets/lsqb/Person_likes_Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));
const rapidcsv::Document POST_CSV("../datasets/lsqb/Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(3));

auto comment = std::tuple(/* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
        /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto pht = std::tuple(/* PostId */ PHT_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(PHT_CSV.GetRowCount()));

auto plp = std::tuple(/* PostId */ PLP_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(PLP_CSV.GetRowCount()));

auto post = std::tuple(/* PostId */ POST_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(POST_CSV.GetRowCount()));

int main() {
    vector<int> pht_offsets(std::get<1>(pht));
    iota(pht_offsets.begin(), pht_offsets.end(), 0);
    sort(pht_offsets.begin(), pht_offsets.end(), [&](const int i, const int j) { return std::get<0>(pht)[i] < std::get<0>(pht)[j]; });
    vector<int> plp_offsets(std::get<1>(plp));
    iota(plp_offsets.begin(), plp_offsets.end(), 0);
    sort(plp_offsets.begin(), plp_offsets.end(), [&](const int i, const int j) { return std::get<0>(plp)[i] < std::get<0>(plp)[j]; });
    vector<int> post_offsets(std::get<1>(post));
    iota(post_offsets.begin(), post_offsets.end(), 0);
    sort(post_offsets.begin(), post_offsets.end(), [&](const int i, const int j) { return std::get<0>(post)[i] < std::get<0>(post)[j]; });
    vector<int> comment_offsets(std::get<1>(comment));
    iota(comment_offsets.begin(), comment_offsets.end(), 0);
    sort(comment_offsets.begin(), comment_offsets.end(), [&](const int i, const int j) { return std::get<0>(comment)[i] < std::get<0>(comment)[j]; });

    HighPrecisionTimer timer;
    for (int iter = 0; iter <= 5; iter++) {
        timer.Reset();
        SortedDict<long, int> post_trie0(/* size */ std::get<1>(post));
        for (int i = 0; i < /* size */ std::get<1>(post); i++) {
            post_trie0[/* PostId */ std::get<0>(post)[post_offsets[i]]] += 1;
        }
        SortedDict<long, int> pht_trie0(/* size */ std::get<1>(pht));
        for (int i = 0; i < /* size */ std::get<1>(pht); i++) {
            pht_trie0[/* PostId */ std::get<0>(pht)[pht_offsets[i]]] += 1;
        }
        auto interm0_trie0 = phmap::flat_hash_map<long, int>({});
        for (const auto &[x0, post_trie1]: post_trie0) {
            const auto pht_it = pht_trie0.find(x0);
            if (pht_it != pht_trie0.end()) {
                const auto &pht_trie1 = pht_it->second;
                interm0_trie0[x0] += (pht_trie1 * post_trie1);
            }
        }
        SortedDict<long, int> comment_trie0(/* size */ std::get<1>(comment));
        for (int i = 0; i < /* size */ std::get<1>(comment); i++) {
            comment_trie0[/* replyOf_PostId */ std::get<0>(comment)[comment_offsets[i]]] += 1;
        }
        SortedDict<long, int> plp_trie0(/* size */ std::get<1>(plp));
        for (int i = 0; i < /* size */ std::get<1>(plp); i++) {
            plp_trie0[/* PostId */ std::get<0>(plp)[plp_offsets[i]]] += 1;
        }
        auto result = int(0);
        for (const auto &[x0, comment_trie1]: comment_trie0) {
            const auto interm0_it = interm0_trie0.find(x0);
            if (interm0_it != interm0_trie0.end()) {
                const auto plp_it = plp_trie0.find(x0);
                if (plp_it != plp_trie0.end()) {
                    const auto &interm0_trie1 = interm0_it->second;
                    const auto &plp_trie1 = plp_it->second;
                    result += (interm0_trie1 * plp_trie1 * comment_trie1);
                }
            }
        }
        timer.StoreElapsedTime(0);
        std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
    }
    cout << timer.GetMean(0) << " ms" << endl;
}