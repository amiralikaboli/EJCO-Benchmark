#include "../../../../runtime/headers.h"

const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document PKP_CSV("../datasets/lsqb/Person_knows_Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document POST_CSV("../datasets/lsqb/Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));

auto comment = std::tuple(/* hasCreator_PersonId */ COMMENT_CSV.GetColumn<long>(1),
        /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
        /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto pkp = std::tuple(/* Person1Id */ PKP_CSV.GetColumn<long>(0),
        /* Person2Id */ PKP_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(PKP_CSV.GetRowCount()));

auto post = std::tuple(/* PostId */ POST_CSV.GetColumn<long>(0),
        /* hasCreator_PersonId */ POST_CSV.GetColumn<long>(1),
        /* size */ static_cast<int>(POST_CSV.GetRowCount()));

int main() {
    vector<int> pkp_offsets(std::get<2>(pkp));
    iota(pkp_offsets.begin(), pkp_offsets.end(), 0);
    sort(pkp_offsets.begin(), pkp_offsets.end(), [&](const int i, const int j) { if (std::get<1>(pkp)[i] != std::get<1>(pkp)[j]) return std::get<1>(pkp)[i] < std::get<1>(pkp)[j]; return std::get<0>(pkp)[i] < std::get<0>(pkp)[j]; });
    vector<int> post_offsets(std::get<2>(post));
    iota(post_offsets.begin(), post_offsets.end(), 0);
    sort(post_offsets.begin(), post_offsets.end(), [&](const int i, const int j) { if (std::get<0>(post)[i] != std::get<0>(post)[j]) return std::get<0>(post)[i] < std::get<0>(post)[j]; return std::get<1>(post)[i] < std::get<1>(post)[j]; });
    vector<int> comment_offsets(std::get<2>(comment));
    iota(comment_offsets.begin(), comment_offsets.end(), 0);
    sort(comment_offsets.begin(), comment_offsets.end(), [&](const int i, const int j) { if (std::get<1>(comment)[i] != std::get<1>(comment)[j]) return std::get<1>(comment)[i] < std::get<1>(comment)[j]; return std::get<0>(comment)[i] < std::get<0>(comment)[j]; });

    HighPrecisionTimer timer;
    for (int iter = 0; iter <= 5; ++iter) {
        timer.Reset();
        SortedDict<long, SortedDict<long, int>> comment_trie0(/* size */ std::get<2>(comment));
        for (int i = 0; i < /* size */ std::get<2>(comment); i++) {
            comment_trie0[/* replyOf_PostId */ std::get<1>(comment)[comment_offsets[i]]][/* hasCreator_PersonId */ std::get<0>(comment)[comment_offsets[i]]] += 1;
        }
        SortedDict<long, SortedDict<long, int>> post_trie0(/* size */ std::get<2>(post));
        for (int i = 0; i < /* size */ std::get<2>(post); i++) {
            post_trie0[/* PostId */ std::get<0>(post)[post_offsets[i]]][/* hasCreator_PersonId */ std::get<1>(post)[post_offsets[i]]] += 1;
        }
        SortedDict<long, SortedDict<long, int>> pkp_trie0(get<2>(pkp));
        for (int i = 0; i < /* size */ std::get<2>(pkp); i++) {
            pkp_trie0[/* Person2Id */ std::get<1>(pkp)[pkp_offsets[i]]][/* Person1Id */ std::get<0>(pkp)[pkp_offsets[i]]] += 1;
        }
        auto result = int(0);
        for (const auto &[x0, comment_trie1]: comment_trie0) {
            const auto post_it = post_trie0.find(x0);
            if (post_it != post_trie0.end()) {
                const auto &post_trie1 = post_it->second;
                for (const auto &[x1, post_trie2]: post_trie1) {
                    const auto pkp_it = pkp_trie0.find(x1);
                    if (pkp_it != pkp_trie0.end()) {
                        auto &pkp_trie1 = pkp_it->second;
                        for (const auto &[x2, comment_trie2]: comment_trie1) {
                            const auto pkp_it2 = pkp_trie1.find(x2);
                            if (pkp_it2 != pkp_trie1.end()) {
                                const auto &pkp_trie2 = pkp_it2->second;
                                result += comment_trie2 * post_trie2 * pkp_trie2;
                            }
                        }
                    }
                }
            }
        }
        timer.StoreElapsedTime(0);
        std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
    }
    cout << timer.GetMean(0) << " ms" << endl;
}