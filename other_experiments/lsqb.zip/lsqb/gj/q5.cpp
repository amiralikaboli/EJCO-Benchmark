#include "../../../runtime/headers.h"

const rapidcsv::Document CHT_CSV("../datasets/lsqb/Comment_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document PHT_CSV("../datasets/lsqb/Post_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));

auto cht = std::tuple(/* CommentId */ CHT_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(CHT_CSV.GetRowCount()));

auto comment = std::tuple(/* CommentId */ COMMENT_CSV.GetColumn<long>(0),
        /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
        /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto pht = std::tuple(/* PostId */ PHT_CSV.GetColumn<long>(0),
        /* size */ static_cast<int>(PHT_CSV.GetRowCount()));

int main() {

    auto comment_trie0 = phmap::flat_hash_map<long, phmap::flat_hash_map<long, int>>(/* size */ std::get<2>(comment));
    for (int i = 0; i < /* size */ std::get<2>(comment); i++) {
        comment_trie0[/* CommentId */ std::get<0>(comment)[i]][/* replyOf_PostId */ std::get<1>(comment)[i]] += 1;
    }
    auto cht_trie0 = phmap::flat_hash_map<long, int>(/* size */ std::get<1>(cht));
    for (int i = 0; i < /* size */ std::get<1>(cht); i++) {
        cht_trie0[/* CommentId */ std::get<0>(cht)[i]] += 1;
    }
    auto pht_trie0 = phmap::flat_hash_map<long, int>({});
    for (int i = 0; i < /* size */ std::get<1>(pht); i++) {
        pht_trie0[/* PostId */ std::get<0>(pht)[i]] += 1;
    }
    auto result = int(0);
    for (auto &[x0, cht_trie1]: cht_trie0) {
        if (comment_trie0.contains(x0)) {
            auto &comment_trie1 = comment_trie0[x0];
            for (auto &[x1, comment_trie2]: comment_trie1) {
                if (pht_trie0.contains(x1)) {
                    auto pht_trie1 = pht_trie0[x1];
                    result += ((comment_trie2 * pht_trie1) * cht_trie1);
                }
            }
        }
    }
    std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
}