#include "../../../runtime/headers.h"

const rapidcsv::Document CHT_CSV("../datasets/lsqb/Comment_hasTag_Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document CITY_CSV("../datasets/lsqb/City.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));
const rapidcsv::Document COUNTRY_CSV("../datasets/lsqb/Country.csv", NO_HEADERS, SEPARATOR, IntNanConverter(3));
const rapidcsv::Document FHP_CSV("../datasets/lsqb/Forum_hasMember_Person.csv", NO_HEADERS, SEPARATOR,
                                 IntNanConverter(4));
const rapidcsv::Document FORUM_CSV("../datasets/lsqb/Forum.csv", NO_HEADERS, SEPARATOR, IntNanConverter(5));
const rapidcsv::Document PERSON_CSV("../datasets/lsqb/Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(6));
const rapidcsv::Document POST_CSV("../datasets/lsqb/Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(7));
const rapidcsv::Document TAG_CSV("../datasets/lsqb/Tag.csv", NO_HEADERS, SEPARATOR, IntNanConverter(8));
const rapidcsv::Document TAGCLASS_CSV("../datasets/lsqb/TagClass.csv", NO_HEADERS, SEPARATOR, IntNanConverter(9));

auto cht = std::tuple(/* CommentId */ CHT_CSV.GetColumn<long>(0),
                      /* TagId */ CHT_CSV.GetColumn<long>(1),
                      /* size */ static_cast<int>(CHT_CSV.GetRowCount()));

auto city = std::tuple(/* CityId */ CITY_CSV.GetColumn<long>(0),
                       /* isPartOf_CountryId */ CITY_CSV.GetColumn<long>(1),
                       /* size */ static_cast<int>(CITY_CSV.GetRowCount()));

auto comment = std::tuple(/* CommentId */ COMMENT_CSV.GetColumn<long>(0),
                          /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
                          /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto country = std::tuple(/* CountryId */ COUNTRY_CSV.GetColumn<long>(0),
                          /* size */ static_cast<int>(COUNTRY_CSV.GetRowCount()));

auto fhp = std::tuple(/* ForumId */ FHP_CSV.GetColumn<long>(0),
                      /* PersonId */ FHP_CSV.GetColumn<long>(1),
                      /* size */ static_cast<int>(FHP_CSV.GetRowCount()));

auto forum = std::tuple(/* ForumId */ FORUM_CSV.GetColumn<long>(0),
                        /* size */ static_cast<int>(FORUM_CSV.GetRowCount()));

auto person = std::tuple(/* PersonId */ PERSON_CSV.GetColumn<long>(0),
                         /* isLocatedIn_CityId */ PERSON_CSV.GetColumn<long>(1),
                         /* size */ static_cast<int>(PERSON_CSV.GetRowCount()));

auto post = std::tuple(/* PostId */ POST_CSV.GetColumn<long>(0),
                       /* Forum_containerOfId */ POST_CSV.GetColumn<long>(2),
                       /* size */ static_cast<int>(POST_CSV.GetRowCount()));

auto tag = std::tuple(/* TagId */ TAG_CSV.GetColumn<long>(0),
                      /* hasType_TagClassId */ TAG_CSV.GetColumn<long>(1),
                      /* size */ static_cast<int>(TAG_CSV.GetRowCount()));

auto tagclass = std::tuple(/* TagClassId */ TAGCLASS_CSV.GetColumn<long>(0),
                           /* size */ static_cast<int>(TAGCLASS_CSV.GetRowCount()));

int main() {

  auto tagclass_trie0 = phmap::flat_hash_map<long, int>(/* size */ std::get<1>(tagclass));
  for (int i = 0; i < /* size */ std::get<1>(tagclass); i++) {
    tagclass_trie0[/* TagClassId */ std::get<0>(tagclass)[i]] += 1;
  }
  auto interm0_trie0 = phmap::flat_hash_map<long, int>({});
  for (int tag_off = 0; tag_off < /* size */ std::get<2>(tag); tag_off++) {
    auto x0 = /* hasType_TagClassId */ std::get<1>(tag)[tag_off];
    if (tagclass_trie0.contains(x0)) {
      auto tagclass_trie1 = tagclass_trie0[x0];
      interm0_trie0[/* TagId */ std::get<0>(tag)[tag_off]] += tagclass_trie1;
    }
  }
  auto comment_trie0 = phmap::flat_hash_map<long, smallvecdict<int, 4>>(/* size */ std::get<2>(comment));
  for (int i = 0; i < /* size */ std::get<2>(comment); i++) {
    comment_trie0[/* CommentId */ std::get<0>(comment)[i]][i] += 1;
  }
  auto post_trie0 = phmap::flat_hash_map<long, smallvecdict<int, 4>>(/* size */ std::get<2>(post));
  for (int i = 0; i < /* size */ std::get<2>(post); i++) {
    post_trie0[/* PostId */ std::get<0>(post)[i]][i] += 1;
  }
  auto forum_trie0 = phmap::flat_hash_map<long, int>(/* size */ std::get<1>(forum));
  for (int i = 0; i < /* size */ std::get<1>(forum); i++) {
    forum_trie0[/* ForumId */ std::get<0>(forum)[i]] += 1;
  }
  auto interm1_trie0 = phmap::flat_hash_map<long, int>({});
  for (int cht_off = 0; cht_off < /* size */ std::get<2>(cht); cht_off++) {
    auto x0 = /* TagId */ std::get<1>(cht)[cht_off];
    if (interm0_trie0.contains(x0)) {
      auto interm0_trie1 = interm0_trie0[x0];
      auto x1 = /* CommentId */ std::get<0>(cht)[cht_off];
      if (comment_trie0.contains(x1)) {
        auto &comment_trie1 = comment_trie0[x1];
        for (auto &comment_off : comment_trie1) {
          auto x2 = /* replyOf_PostId */ std::get<1>(comment)[comment_off];
          if (post_trie0.contains(x2)) {
            auto &post_trie1 = post_trie0[x2];
            for (auto &post_off : post_trie1) {
              auto x3 = /* Forum_containerOfId */ std::get<1>(post)[post_off];
              if (forum_trie0.contains(x3)) {
                auto forum_trie1 = forum_trie0[x3];
                interm1_trie0[x3] += (forum_trie1 * interm0_trie1);
              }
            }
          }
        }
      }
    }
  }
  auto person_trie0 = phmap::flat_hash_map<long, smallvecdict<int, 4>>(/* size */ std::get<2>(person));
  for (int i = 0; i < /* size */ std::get<2>(person); i++) {
    person_trie0[/* PersonId */ std::get<0>(person)[i]][i] += 1;
  }
  auto city_trie0 = phmap::flat_hash_map<long, smallvecdict<int, 4>>(/* size */ std::get<2>(city));
  for (int i = 0; i < /* size */ std::get<2>(city); i++) {
    city_trie0[/* CityId */ std::get<0>(city)[i]][i] += 1;
  }
  auto country_trie0 = phmap::flat_hash_map<long, int>(/* size */ std::get<1>(country));
  for (int i = 0; i < /* size */ std::get<1>(country); i++) {
    country_trie0[/* CountryId */ std::get<0>(country)[i]] += 1;
  }
  auto result = int(0);
  for (int fhp_off = 0; fhp_off < /* size */ std::get<2>(fhp); fhp_off++) {
    auto x0 = /* ForumId */ std::get<0>(fhp)[fhp_off];
    if (interm1_trie0.contains(x0)) {
      auto interm1_trie1 = interm1_trie0[x0];
      auto x1 = /* PersonId */ std::get<1>(fhp)[fhp_off];
      if (person_trie0.contains(x1)) {
        auto &person_trie1 = person_trie0[x1];
        for (auto &person_off : person_trie1) {
          auto x2 = /* isLocatedIn_CityId */ std::get<1>(person)[person_off];
          if (city_trie0.contains(x2)) {
            auto &city_trie1 = city_trie0[x2];
            for (auto &city_off : city_trie1) {
              auto x3 = /* isPartOf_CountryId */ std::get<1>(city)[city_off];
              if (country_trie0.contains(x3)) {
                auto country_trie1 = country_trie0[x3];
                result += (interm1_trie1 * country_trie1);
              }
            }
          }
        }
      }
    }
  }
  std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
}