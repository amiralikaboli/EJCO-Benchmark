#include "../../../runtime/headers.h"

const rapidcsv::Document COMMENT_CSV("../datasets/lsqb/Comment.csv", NO_HEADERS, SEPARATOR, IntNanConverter(0));
const rapidcsv::Document PKP_CSV("../datasets/lsqb/Person_knows_Person.csv", NO_HEADERS, SEPARATOR, IntNanConverter(1));
const rapidcsv::Document POST_CSV("../datasets/lsqb/Post.csv", NO_HEADERS, SEPARATOR, IntNanConverter(2));

auto comment = std::tuple(/* hasCreator_PersonId */ COMMENT_CSV.GetColumn<long>(1),
                          /* replyOf_PostId */ COMMENT_CSV.GetColumn<long>(3),
                          /* size */ static_cast<int>(COMMENT_CSV.GetRowCount()));

auto pkp = std::tuple(/* Person1Id */ PKP_CSV.GetColumn<long>(0),
                      /* Person2Id */ PKP_CSV.GetColumn<long>(1),
                      /* size */ static_cast<int>(PKP_CSV.GetRowCount()));

auto post = std::tuple(/* PostId */ POST_CSV.GetColumn<long>(0),
                       /* hasCreator_PersonId */ POST_CSV.GetColumn<long>(1),
                       /* size */ static_cast<int>(POST_CSV.GetRowCount()));

int main() {

  auto post_trie0 = phmap::flat_hash_map<long, smallvecdict<int, 4>>(/* size */ std::get<2>(post));
  for (int i = 0; i < /* size */ std::get<2>(post); i++) {
    post_trie0[/* PostId */ std::get<0>(post)[i]][i] += 1;
  }
  auto pkp_trie0 = phmap::flat_hash_map<long, phmap::flat_hash_map<long, int>>(/* size */ std::get<2>(pkp));
  for (int i = 0; i < /* size */ std::get<2>(pkp); i++) {
    pkp_trie0[/* Person2Id */ std::get<1>(pkp)[i]][/* Person1Id */ std::get<0>(pkp)[i]] += 1;
  }
  auto result = int(0);
  for (int comment_off = 0; comment_off < /* size */ std::get<2>(comment); comment_off++) {
    auto x0 = /* replyOf_PostId */ std::get<1>(comment)[comment_off];
    if (post_trie0.contains(x0)) {
      auto &post_trie1 = post_trie0[x0];
      for (auto &post_off : post_trie1) {
        auto x1 = /* hasCreator_PersonId */ std::get<1>(post)[post_off];
        if (pkp_trie0.contains(x1)) {
          auto &pkp_trie1 = pkp_trie0[x1];
          auto x2 = /* hasCreator_PersonId */ std::get<0>(comment)[comment_off];
          if (pkp_trie1.contains(x2)) {
            auto pkp_trie2 = pkp_trie1[x2];
            result += pkp_trie2;
          }
        }
      }
    }
  }
  std::cout << std::setprecision(std::numeric_limits<double>::digits10) << result << std::endl;
}